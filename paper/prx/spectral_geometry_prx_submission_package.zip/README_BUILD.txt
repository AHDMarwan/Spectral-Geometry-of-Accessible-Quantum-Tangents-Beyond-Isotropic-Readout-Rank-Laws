PRX combined manuscript package

The Supplemental Material has been integrated into the manuscript as Appendices A-E.
Build from this directory with:
  pdflatex -interaction=nonstopmode spectral_geometry_prx.tex
  pdflatex -interaction=nonstopmode spectral_geometry_prx.tex

The manuscript uses REVTeX 4.2 and vector PDF figures in figures/.
